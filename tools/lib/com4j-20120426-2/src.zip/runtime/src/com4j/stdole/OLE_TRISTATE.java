package com4j.stdole;


/**
 * <p>
 * This enum was generated using tlbimp on stdole2.tlb
 * </p>
*/
public enum OLE_TRISTATE {
  /**
   * <p>
   * The value of this constant is 0
   * </p>
   */
  Unchecked, // 0
  /**
   * <p>
   * The value of this constant is 1
   * </p>
   */
  Checked, // 1
  /**
   * <p>
   * The value of this constant is 2
   * </p>
   */
  Gray, // 2
}
