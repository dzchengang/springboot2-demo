package com4j.tlbimp.def;

import com4j.Com4jObject;
import com4j.IID;

/**
 * @author Kohsuke Kawaguchi (kk@kohsuke.org)
 */
@IID("{ED0810B4-3662-4fe7-8FA7-446C465B2847}")
public interface IType extends Com4jObject {
}
